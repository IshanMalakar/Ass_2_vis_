var vg_3 = "json/bubble_chart.vg.json";
vegaEmbed("#bubble_chart", vg_3).then(function(result) {
    // Access the Vega view instance as result.view
}).catch(console.error);
